# Plants vs Zombies (LITE)
## Game Logic
key points to keep a note of
- 10% chance you encounter a superzombie
- superzombie has x2 health and 30% speed boost
- you get $50 for killing a zombie
- 

## Controls
| KEYBIND | ACTION |
|--------:|--------|
|P|Buy Plant|
|U|Buy Upgrades|
|B|Check Wallet Balance|

## Upgrades available
- Can buy new plant (up to 6 plants)
- Can increase plant strength (up to Lvl3)
- Can increase pea(bullt) strength (up to Lvl3)
- Can increase pea(bullet) speed (up to Lvl3)
### Prices
|Item|Price|
|----|-----|
|PLANT ITEMS|====|
|New Plant|$250|
|Strength 2|$200|
|Strength 3|$400|
|PEA ITEMS|====|
|Strength 2|$100|
|Strength 3|$300|
|Speed 2|$500|
|Speed 3|$1000|
